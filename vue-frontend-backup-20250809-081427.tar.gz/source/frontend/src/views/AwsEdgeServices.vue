<template>
  <div class="page-header">
    <h1>AWS Edge Services</h1>
    <div class="demo-badge">Architecture</div>
  </div>

  <div class="content-section">
    <div class="welcome-card">
      <h2>AWS Edge Services Architecture</h2>
      <p>This demo leverages multiple AWS edge services to create a comprehensive bot detection and deception system.</p>
      
      <div class="tech-stack">
        <h3>Services Used</h3>
        <div class="tech-items">
          <span class="tech-item">AWS WAF</span>
          <span class="tech-item">CloudFront</span>
          <span class="tech-item">Application Load Balancer</span>
          <span class="tech-item">Amazon Bedrock</span>
          <span class="tech-item">AWS Lambda</span>
          <span class="tech-item">Amazon S3</span>
        </div>
      </div>
    </div>
    
    <div class="demo-explanation">
      <h2>Service Details</h2>
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>🛡️ AWS WAF</h3>
          <ul>
            <li>Bot Control managed rule group</li>
            <li>Machine learning-based detection</li>
            <li>Custom bot detection headers</li>
            <li>Real-time traffic analysis</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>🌐 CloudFront</h3>
          <ul>
            <li>Global content delivery network</li>
            <li>CloudFront Functions for logic</li>
            <li>Origin request/response manipulation</li>
            <li>Edge-based bot handling</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>⚖️ Application Load Balancer</h3>
          <ul>
            <li>Backend service routing</li>
            <li>Health check monitoring</li>
            <li>Multiple target groups</li>
            <li>Timeout ALB for bot trapping</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>🤖 Amazon Bedrock</h3>
          <ul>
            <li>AI-generated fake content</li>
            <li>Claude 3 Sonnet model</li>
            <li>Dynamic content creation</li>
            <li>Bot deception materials</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>⚡ AWS Lambda</h3>
          <ul>
            <li>Serverless API backend</li>
            <li>Auto-scaling compute</li>
            <li>Event-driven processing</li>
            <li>Cost-effective execution</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>🪣 Amazon S3</h3>
          <ul>
            <li>Static website hosting</li>
            <li>Fake content storage</li>
            <li>CloudFront origin</li>
            <li>Access logging</li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="technical-stats">
      <h2>Architecture Benefits</h2>
      <div class="stats-grid">
        <div class="stat-item">
          <div class="stat-number">99.9%</div>
          <div class="stat-label">Availability</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">&lt;100ms</div>
          <div class="stat-label">Edge Latency</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">Global</div>
          <div class="stat-label">Coverage</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">Auto</div>
          <div class="stat-label">Scaling</div>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Explore More</h2>
      <div class="next-buttons">
        <router-link to="/" class="btn btn-primary">Back to Home</router-link>
        <router-link to="/bot-demo-1-info" class="btn btn-secondary">Try Demo 1</router-link>
        <router-link to="/bot-demo-2-info" class="btn btn-outline">Try Demo 2</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AwsEdgeServices'
}
</script>
