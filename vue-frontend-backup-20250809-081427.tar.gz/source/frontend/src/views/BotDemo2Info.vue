<template>
  <div class="page-header">
    <h1>Bot Demo 2: Silent Discard</h1>
    <div class="demo-badge">Information</div>
  </div>

  <div class="content-section">
    <div class="demo-explanation">
      <h2>Overview</h2>
      <p>This demo demonstrates how to silently discard bot-generated content while making the bot believe its actions were successful, effectively wasting bot resources and preventing spam.</p>
      
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>🎯 Objective</h3>
          <ul>
            <li>Prevent bot-generated spam</li>
            <li>Deceive bots into thinking they succeeded</li>
            <li>Maintain clean user experience</li>
            <li>Reduce bot motivation to continue</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>⚙️ Technical Implementation</h3>
          <ul>
            <li>Server detects bot via WAF headers</li>
            <li>Bot comments marked as "silent_discard"</li>
            <li>Success response sent to bot</li>
            <li>Comments hidden from public view</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>📊 Expected Results</h3>
          <ul>
            <li>Zero spam in public comments</li>
            <li>Bots believe they're successful</li>
            <li>Continued bot engagement (wasting resources)</li>
            <li>Clean experience for real users</li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Ready to Test?</h2>
      <p>Try leaving a comment to see how the system handles bot vs. legitimate user submissions differently.</p>
      <div class="next-buttons">
        <router-link to="/bot-demo-2" class="btn btn-primary">Start Demo 2</router-link>
        <router-link to="/bot-demo-3-info" class="btn btn-secondary">Next: Demo 3 Info</router-link>
        <router-link to="/bot-demo-1-info" class="btn btn-outline">Back: Demo 1 Info</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BotDemo2Info'
}
</script>
