<template>
  <div class="page-header">
    <h1>Bot Demo 2: Silent Discard</h1>
    <div :class="['status-indicator', isBot ? 'bot-detected' : 'normal']">
      {{ isBot ? 'Bot Detected' : 'Normal User' }}
    </div>
  </div>

  <div class="content-section">
    <!-- Comment Form Section -->
    <div class="comment-form-section">
      <h2>Leave a Comment</h2>
      <form @submit.prevent="submitComment" class="comment-form">
        <div class="form-group">
          <label for="commenter">Name:</label>
          <input
            id="commenter"
            v-model="commentForm.commenter"
            type="text"
            placeholder="Enter your name"
            required
          />
        </div>
        
        <div class="form-group">
          <label for="details">Comment:</label>
          <textarea
            id="details"
            v-model="commentForm.details"
            placeholder="Enter your comment"
            rows="4"
            required
          ></textarea>
          <div class="char-counter">
            {{ commentForm.details.length }}/1000 characters
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary" :disabled="isSubmitting">
          {{ isSubmitting ? 'Submitting...' : 'Submit Comment' }}
        </button>
      </form>
    </div>
    
    <!-- Bot/User Info Panel -->
    <div v-if="isBot" class="bot-info-panel">
      <h3>🤖 Bot Behavior</h3>
      <p>As a bot, your comments will be silently discarded. You'll see a success message, but your comment won't appear in the public list. However, you can still see all comments including your own discarded ones.</p>
    </div>
    
    <div v-else class="user-info-panel">
      <h3>👤 Normal User</h3>
      <p>As a legitimate user, your comments will be saved and displayed publicly. You can only see approved comments from other users.</p>
    </div>
    
    <!-- Comments Section -->
    <div class="comments-section">
      <h2>Comments ({{ comments.length }})</h2>
      
      <div v-if="isLoadingComments" class="loading-comments">
        <div class="spinner"></div>
        <p>Loading comments...</p>
      </div>
      
      <div v-else-if="comments.length === 0" class="no-comments">
        <div class="no-comments-icon">💬</div>
        <p>No comments yet. Be the first to leave a comment!</p>
      </div>
      
      <div v-else class="comments-list">
        <div
          v-for="comment in comments"
          :key="comment.id"
          :class="['comment-item', comment.silent_discard ? 'bot-comment' : 'normal-comment']"
        >
          <div class="comment-header">
            <div class="comment-author">
              <span class="bot-badge" v-if="comment.silent_discard">🤖</span>
              <span class="user-badge" v-else>👤</span>
              <strong>{{ comment.commenter }}</strong>
            </div>
            <div class="comment-date">
              {{ formatDate(comment.created_at) }}
            </div>
          </div>
          
          <div class="comment-content">
            {{ comment.details }}
          </div>
          
          <div v-if="comment.silent_discard" class="comment-status">
            <span class="status-badge silent-discard">Silent Discard</span>
            <small>This comment was silently discarded (only visible to bots)</small>
          </div>
        </div>
      </div>
    </div>
    
    <div class="demo-explanation">
      <h2>How Silent Discard Works</h2>
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>Detection</h3>
          <ul>
            <li>AWS WAF identifies bot traffic</li>
            <li>Adds detection header to request</li>
            <li>Server reads the header</li>
            <li>Determines appropriate action</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>Processing</h3>
          <ul>
            <li>Bot comments marked as "silent_discard"</li>
            <li>Stored in database but hidden</li>
            <li>Success response sent to bot</li>
            <li>Bot believes comment was published</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>Benefits</h3>
          <ul>
            <li>Prevents spam from appearing</li>
            <li>Deceives bots into thinking they succeeded</li>
            <li>Maintains normal user experience</li>
            <li>Reduces bot motivation to continue</li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Next Steps</h2>
      <div class="next-buttons">
        <router-link to="/bot-demo-3-info" class="btn btn-primary">Try Demo 3</router-link>
        <router-link to="/bot-demo-1-info" class="btn btn-secondary">Back to Demo 1</router-link>
        <router-link to="/" class="btn btn-outline">Back to Home</router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted, reactive } from 'vue'
import { useAppStore } from '../stores/app'
import api from '../services/api'

export default {
  name: 'BotDemo2',
  setup() {
    const appStore = useAppStore()
    const comments = ref([])
    const isLoadingComments = ref(false)
    const isSubmitting = ref(false)
    
    const commentForm = reactive({
      commenter: '',
      details: ''
    })
    
    const isBot = computed(() => appStore.isBot)
    
    const loadComments = async () => {
      try {
        isLoadingComments.value = true
        const response = await api.getBotDemo2Comments()
        comments.value = response.data.comments
      } catch (error) {
        appStore.handleApiError(error)
      } finally {
        isLoadingComments.value = false
      }
    }
    
    const submitComment = async () => {
      if (!commentForm.commenter.trim() || !commentForm.details.trim()) {
        appStore.addNotification('Please fill in all fields', 'warning')
        return
      }
      
      try {
        isSubmitting.value = true
        const response = await api.postBotDemo2Comment({
          commenter: commentForm.commenter.trim(),
          details: commentForm.details.trim()
        })
        
        if (response.data.success) {
          appStore.addNotification('Comment submitted successfully!', 'success')
          
          // Reset form
          commentForm.commenter = ''
          commentForm.details = ''
          
          // Reload comments to show the new one
          await loadComments()
        }
      } catch (error) {
        appStore.handleApiError(error)
      } finally {
        isSubmitting.value = false
      }
    }
    
    const formatDate = (timestamp) => {
      // Handle both timestamp numbers and date strings
      let date
      if (typeof timestamp === 'number') {
        date = new Date(timestamp)
      } else if (typeof timestamp === 'string') {
        date = new Date(timestamp)
      } else {
        return 'Invalid Date'
      }
      
      // Check if date is valid
      if (isNaN(date.getTime())) {
        return 'Invalid Date'
      }
      
      return date.toLocaleString()
    }
    
    onMounted(() => {
      loadComments()
    })
    
    return {
      comments,
      isLoadingComments,
      isSubmitting,
      commentForm,
      isBot,
      submitComment,
      formatDate
    }
  }
}
</script>

<style scoped>
.loading-comments {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  padding: 2rem;
  color: var(--text-secondary);
}

.char-counter {
  font-size: 0.75rem;
  color: var(--text-muted);
  text-align: right;
  margin-top: 0.25rem;
}
</style>
