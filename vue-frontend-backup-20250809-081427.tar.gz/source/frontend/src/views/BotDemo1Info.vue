<template>
  <div class="page-header">
    <h1>Bot Demo 1: Timeout Induction</h1>
    <div class="demo-badge">Information</div>
  </div>

  <div class="content-section">
    <div class="demo-explanation">
      <h2>Overview</h2>
      <p>This demo showcases how to waste bot resources by redirecting them to unreachable endpoints, causing timeouts and discouraging further scraping attempts.</p>
      
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>🎯 Objective</h3>
          <ul>
            <li>Waste bot computational resources</li>
            <li>Increase bot operation costs</li>
            <li>Discourage persistent scraping</li>
            <li>Maintain normal user experience</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>⚙️ Technical Implementation</h3>
          <ul>
            <li>CloudFront Function detects bot traffic</li>
            <li>70% probability redirect to timeout ALB</li>
            <li>Unreachable backend causes 30s timeout</li>
            <li>Normal users access content directly</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>📊 Expected Results</h3>
          <ul>
            <li>Bots experience frequent timeouts</li>
            <li>Reduced bot crawling efficiency</li>
            <li>Higher operational costs for attackers</li>
            <li>Zero impact on legitimate users</li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="technical-stats">
      <h2>Configuration Details</h2>
      <div class="stats-grid">
        <div class="stat-item">
          <div class="stat-number">70%</div>
          <div class="stat-label">Redirect Probability</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">30s</div>
          <div class="stat-label">Timeout Duration</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">0ms</div>
          <div class="stat-label">User Impact</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">100%</div>
          <div class="stat-label">Bot Detection Rate</div>
        </div>
      </div>
    </div>
    
    <div class="welcome-card">
      <h2>How It Works</h2>
      
      <div class="process-flow">
        <div class="flow-step">
          <div class="step-number">1</div>
          <div class="step-content">
            <h4>Request Analysis</h4>
            <p>AWS WAF analyzes incoming requests and identifies bot traffic using machine learning and behavioral analysis.</p>
          </div>
        </div>
        
        <div class="flow-step">
          <div class="step-number">2</div>
          <div class="step-content">
            <h4>Header Injection</h4>
            <p>WAF adds the <code>x-amzn-waf-targeted-bot-detected: true</code> header to requests identified as bot traffic.</p>
          </div>
        </div>
        
        <div class="flow-step">
          <div class="step-number">3</div>
          <div class="step-content">
            <h4>CloudFront Function</h4>
            <p>CloudFront Function checks for the bot header and randomly redirects 70% of bot requests to an unreachable ALB.</p>
          </div>
        </div>
        
        <div class="flow-step">
          <div class="step-number">4</div>
          <div class="step-content">
            <h4>Timeout Induction</h4>
            <p>The unreachable ALB causes a 30-second timeout, wasting bot resources while normal users access content directly.</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Ready to Test?</h2>
      <p>Click the button below to experience the timeout induction demo. The behavior will differ based on whether you're detected as a bot or legitimate user.</p>
      <div class="next-buttons">
        <router-link to="/bot-demo-1" class="btn btn-primary">Start Demo 1</router-link>
        <router-link to="/bot-demo-2-info" class="btn btn-secondary">Next: Demo 2 Info</router-link>
        <router-link to="/" class="btn btn-outline">Back to Home</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BotDemo1Info'
}
</script>

<style scoped>
.process-flow {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-top: 1.5rem;
}

.flow-step {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  padding: 1.5rem;
  background: var(--bg-tertiary);
  border-radius: var(--radius-lg);
  border: 1px solid var(--border-color);
}

.step-number {
  width: 40px;
  height: 40px;
  background: var(--primary-color);
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1.125rem;
  flex-shrink: 0;
}

.step-content h4 {
  color: var(--text-primary);
  margin-bottom: 0.5rem;
  font-size: 1.125rem;
}

.step-content p {
  color: var(--text-secondary);
  line-height: 1.6;
}

.step-content code {
  background: var(--bg-primary);
  padding: 0.25rem 0.5rem;
  border-radius: var(--radius-sm);
  font-size: 0.875rem;
  color: var(--accent-color);
}

@media (max-width: 768px) {
  .flow-step {
    flex-direction: column;
    text-align: center;
  }
  
  .step-number {
    align-self: center;
  }
}
</style>
