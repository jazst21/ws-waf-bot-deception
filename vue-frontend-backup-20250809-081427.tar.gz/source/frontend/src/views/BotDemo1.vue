<template>
  <div class="page-header">
    <h1>Bot Demo 1: Timeout Induction</h1>
    <div :class="['status-indicator', isBot ? 'bot-detected' : 'normal']">
      {{ isBot ? 'Bot Detected' : 'Normal User' }}
    </div>
  </div>

  <div class="content-section">
    <div class="welcome-card">
      <h2>{{ demoMessage }}</h2>
      
      <div class="demo-explanation">
        <h3>How This Demo Works</h3>
        <div class="explanation-grid">
          <div class="explanation-item">
            <h4>For Normal Users</h4>
            <ul>
              <li>Direct access to this page</li>
              <li>Fast response time</li>
              <li>Normal user experience</li>
              <li>No redirects or delays</li>
            </ul>
          </div>
          
          <div class="explanation-item">
            <h4>For Bots</h4>
            <ul>
              <li>70% chance of redirect to timeout ALB</li>
              <li>Unreachable backend causes timeout</li>
              <li>Wastes bot resources and time</li>
              <li>Discourages further scraping</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div v-if="isBot" class="bot-info-panel">
        <h3>🤖 Bot Behavior Simulation</h3>
        <p>As a bot, you have a 70% chance of being redirected to a timeout ALB when accessing this page. The CloudFront function detects bot traffic and redirects it to an unreachable endpoint.</p>
        <p><strong>In production:</strong> Most bot requests to this endpoint would result in timeouts, effectively wasting the bot's time and resources.</p>
        <div class="bot-stats">
          <div class="stat">
            <span class="stat-label">Redirect Probability:</span>
            <span class="stat-value">70%</span>
          </div>
          <div class="stat">
            <span class="stat-label">Expected Outcome:</span>
            <span class="stat-value">Connection Timeout</span>
          </div>
        </div>
      </div>
      
      <div v-else class="user-info-panel">
        <h3>👤 Normal User Experience</h3>
        <p>As a legitimate user, you have direct access to this content without any redirects or delays. The bot detection system recognizes you as a human visitor.</p>
        <p>The CloudFront function only redirects requests that are identified as bots by AWS WAF Bot Control.</p>
      </div>
    </div>
    
    <div class="technical-stats">
      <h2>Technical Implementation</h2>
      <div class="stats-grid">
        <div class="stat-item">
          <div class="stat-number">70%</div>
          <div class="stat-label">Bot Redirect Rate</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">30s</div>
          <div class="stat-label">Timeout Duration</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">CF</div>
          <div class="stat-label">CloudFront Function</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">ALB</div>
          <div class="stat-label">Timeout ALB</div>
        </div>
      </div>
    </div>

    <div class="demo-flow">
      <h2>Request Flow</h2>
      <div class="flow-diagram">
        <div class="flow-step">
          <div class="step-number">1</div>
          <div class="step-content">
            <h4>Request Arrives</h4>
            <p>User/Bot requests /bot-demo-1</p>
          </div>
        </div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">
          <div class="step-number">2</div>
          <div class="step-content">
            <h4>WAF Analysis</h4>
            <p>AWS WAF Bot Control analyzes request</p>
          </div>
        </div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">
          <div class="step-number">3</div>
          <div class="step-content">
            <h4>CloudFront Function</h4>
            <p>Checks bot header, applies 70% redirect</p>
          </div>
        </div>
        <div class="flow-arrow">→</div>
        <div class="flow-step">
          <div class="step-number">4</div>
          <div class="step-content">
            <h4>Final Destination</h4>
            <p v-if="isBot">Timeout ALB (unreachable)</p>
            <p v-else>Normal Content (this page)</p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Next Steps</h2>
      <div class="next-buttons">
        <router-link to="/bot-demo-2-info" class="btn btn-primary">Try Demo 2</router-link>
        <router-link to="/bot-demo-3-info" class="btn btn-secondary">Try Demo 3</router-link>
        <router-link to="/" class="btn btn-outline">Back to Home</router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useAppStore } from '../stores/app'

export default {
  name: 'BotDemo1',
  setup() {
    const appStore = useAppStore()
    
    const isBot = computed(() => appStore.isBot)
    
    const demoMessage = computed(() => {
      if (isBot.value) {
        return "🤖 Bot Detected - Timeout Mechanism Active"
      } else {
        return "👤 Welcome! You're accessing this page as a normal user"
      }
    })
    
    return {
      isBot,
      demoMessage
    }
  }
}
</script>

<style scoped>
.bot-stats {
  margin-top: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.stat {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem;
  background: rgba(255, 193, 7, 0.1);
  border-radius: 4px;
}

.stat-label {
  font-weight: 500;
}

.stat-value {
  font-weight: 700;
  color: var(--warning-color);
}

.demo-flow {
  margin: 2rem 0;
}

.flow-diagram {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 1rem;
  margin: 2rem 0;
}

.flow-step {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  min-width: 150px;
}

.step-number {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: var(--primary-color);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  margin-bottom: 1rem;
}

.step-content h4 {
  margin: 0 0 0.5rem 0;
  color: var(--text-primary);
}

.step-content p {
  margin: 0;
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.flow-arrow {
  font-size: 1.5rem;
  color: var(--primary-color);
  font-weight: bold;
}

@media (max-width: 768px) {
  .flow-diagram {
    flex-direction: column;
  }
  
  .flow-arrow {
    transform: rotate(90deg);
  }
}
</style>
