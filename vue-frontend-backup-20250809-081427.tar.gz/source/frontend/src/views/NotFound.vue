<template>
  <div class="page-header">
    <h1>404 - Page Not Found</h1>
    <div class="status-indicator normal">Error</div>
  </div>

  <div class="content-section">
    <div class="welcome-card">
      <div class="error-content">
        <div class="error-icon">🤖</div>
        <h2>Oops! Page Not Found</h2>
        <p>The page you're looking for doesn't exist. It might have been moved, deleted, or you entered the wrong URL.</p>
        
        <div class="error-details">
          <p><strong>Requested Path:</strong> <code>{{ $route.path }}</code></p>
          <p><strong>Error Code:</strong> 404</p>
        </div>
        
        <div class="next-buttons">
          <router-link to="/" class="btn btn-primary">Go Home</router-link>
          <button @click="goBack" class="btn btn-secondary">Go Back</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NotFound',
  methods: {
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style scoped>
.error-content {
  text-align: center;
  padding: 2rem;
}

.error-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
}

.error-details {
  background: var(--bg-tertiary);
  border-radius: var(--radius-md);
  padding: 1rem;
  margin: 1.5rem 0;
  text-align: left;
}

.error-details code {
  background: var(--bg-primary);
  padding: 0.25rem 0.5rem;
  border-radius: var(--radius-sm);
  color: var(--accent-color);
}
</style>
