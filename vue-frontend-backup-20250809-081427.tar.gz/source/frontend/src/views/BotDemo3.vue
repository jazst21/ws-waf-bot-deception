<template>
  <div class="page-header">
    <h1>Bot Demo 3: Flight Pricing</h1>
    <div :class="['status-indicator', isBot ? 'bot-detected' : 'normal']">
      {{ isBot ? 'Bot Detected' : 'Normal User' }}
    </div>
  </div>

  <div class="content-section">
    <!-- Flight Search Section -->
    <div class="flight-search-section">
      <h2>Available Flights</h2>
      <p v-if="isBot" class="bot-notice">
        🤖 As a bot, you're seeing inflated prices to protect our pricing strategy.
      </p>
      <p v-else class="user-notice">
        👤 As a legitimate user, you're seeing our best discounted prices!
      </p>
      
      <div v-if="isLoadingFlights" class="loading-flights">
        <div class="spinner"></div>
        <p>Loading flights...</p>
      </div>
      
      <div v-else-if="flights.length === 0" class="no-flights">
        <p>No flights available at the moment.</p>
      </div>
      
      <div v-else class="flights-grid">
        <div
          v-for="flight in flights"
          :key="flight.id"
          :class="['flight-card', isBot ? 'bot-flight' : 'user-flight']"
        >
          <div class="flight-header">
            <div class="route-info">
              <h3 class="route">{{ flight.route }}</h3>
              <p class="airline">{{ flight.airline }}</p>
            </div>
            
            <div class="price-section">
              <div v-if="isBot" class="bot-price">
                <div class="price">
                  <span class="currency">$</span>
                  <span class="amount">{{ flight.price }}</span>
                </div>
              </div>
              
              <div v-else class="user-price">
                <div class="price">
                  <span class="currency">$</span>
                  <span class="amount">{{ flight.price }}</span>
                </div>
                <div v-if="flight.discount > 0" class="savings">
                  <span class="original-price">${{ flight.originalPrice }}</span>
                  <span class="discount-badge">{{ flight.discount }}% OFF</span>
                </div>
              </div>
            </div>
          </div>
          
          <div class="flight-details">
            <div class="flight-time">
              <div class="departure">
                <div class="time">{{ flight.departure }}</div>
                <div class="label">Departure</div>
              </div>
              
              <div class="duration">
                <div class="duration-text">{{ flight.duration }}</div>
                <div class="flight-line">
                  <div class="line"></div>
                  <div class="plane">✈️</div>
                </div>
              </div>
              
              <div class="arrival">
                <div class="time">{{ flight.arrival }}</div>
                <div class="label">Arrival</div>
              </div>
            </div>
          </div>
          
          <div class="flight-actions">
            <button class="btn btn-primary" @click="selectFlight(flight)">
              Select Flight
            </button>
            <button class="btn btn-outline" @click="viewDetails(flight)">
              View Details
            </button>
          </div>
          
          <div v-if="isBot" class="bot-notice">
            🤖 Bot pricing: Higher rates to discourage scraping
          </div>
          
          <div v-else class="user-benefit">
            👤 User benefit: {{ flight.discount }}% discount applied!
          </div>
        </div>
      </div>
    </div>
    
    <!-- Demo Explanation -->
    <div class="demo-explanation">
      <h2>How Price Manipulation Works</h2>
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>Bot Detection</h3>
          <ul>
            <li>AWS WAF identifies automated traffic</li>
            <li>Headers indicate bot presence</li>
            <li>Server adjusts pricing logic</li>
            <li>Higher prices shown to bots</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>User Benefits</h3>
          <ul>
            <li>Legitimate users see real prices</li>
            <li>Discount percentages displayed</li>
            <li>Competitive pricing maintained</li>
            <li>Better user experience</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>Business Protection</h3>
          <ul>
            <li>Prevents price scraping</li>
            <li>Protects competitive advantage</li>
            <li>Reduces bot-driven competition</li>
            <li>Maintains pricing strategy</li>
          </ul>
        </div>
      </div>
    </div>
    
    <!-- Technical Stats -->
    <div class="technical-stats">
      <h2>Pricing Statistics</h2>
      <div class="stats-grid">
        <div class="stat-item">
          <div class="stat-number">{{ isBot ? '+30%' : '-25%' }}</div>
          <div class="stat-label">Price Adjustment</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">{{ flights.length }}</div>
          <div class="stat-label">Available Flights</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">{{ isBot ? '$0' : calculateAverageSavings() }}</div>
          <div class="stat-label">Average Savings</div>
        </div>
        <div class="stat-item">
          <div class="stat-number">{{ isBot ? 'HIGH' : 'LOW' }}</div>
          <div class="stat-label">Price Tier</div>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Next Steps</h2>
      <div class="next-buttons">
        <router-link to="/aws-edge-services" class="btn btn-primary">AWS Edge Services</router-link>
        <router-link to="/bot-demo-2-info" class="btn btn-secondary">Back to Demo 2</router-link>
        <router-link to="/" class="btn btn-outline">Back to Home</router-link>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useAppStore } from '../stores/app'
import api from '../services/api'

export default {
  name: 'BotDemo3',
  setup() {
    const appStore = useAppStore()
    const flights = ref([])
    const isLoadingFlights = ref(false)
    
    const isBot = computed(() => appStore.isBot)
    
    const loadFlights = async () => {
      try {
        isLoadingFlights.value = true
        const response = await api.getBotDemo3Flights()
        flights.value = response.data.flights
      } catch (error) {
        appStore.handleApiError(error)
      } finally {
        isLoadingFlights.value = false
      }
    }
    
    const selectFlight = (flight) => {
      appStore.addNotification(
        `Selected flight: ${flight.route} for $${flight.price}`,
        'success'
      )
    }
    
    const viewDetails = (flight) => {
      appStore.addNotification(
        `Viewing details for ${flight.airline} flight`,
        'info'
      )
    }
    
    const calculateAverageSavings = () => {
      if (flights.value.length === 0) return '$0'
      
      const totalSavings = flights.value.reduce((sum, flight) => {
        return sum + (flight.originalPrice - flight.price)
      }, 0)
      
      const averageSavings = Math.round(totalSavings / flights.value.length)
      return `$${averageSavings}`
    }
    
    onMounted(() => {
      loadFlights()
    })
    
    return {
      flights,
      isLoadingFlights,
      isBot,
      selectFlight,
      viewDetails,
      calculateAverageSavings
    }
  }
}
</script>

<style scoped>
.loading-flights {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  padding: 2rem;
  color: var(--text-secondary);
}

.bot-notice,
.user-notice {
  padding: 1rem;
  border-radius: var(--radius-md);
  margin-bottom: 1.5rem;
  font-weight: 500;
}

.bot-notice {
  background: rgba(239, 68, 68, 0.1);
  color: var(--danger-color);
  border: 1px solid rgba(239, 68, 68, 0.2);
}

.user-notice {
  background: rgba(16, 185, 129, 0.1);
  color: var(--success-color);
  border: 1px solid rgba(16, 185, 129, 0.2);
}

.no-flights {
  text-align: center;
  padding: 2rem;
  color: var(--text-muted);
}
</style>
