<template>
  <div class="page-header">
    <h1>Bot Demo 3: Price Manipulation</h1>
    <div class="demo-badge">Information</div>
  </div>

  <div class="content-section">
    <div class="demo-explanation">
      <h2>Overview</h2>
      <p>This demo shows how to protect pricing strategies by showing inflated prices to bots while offering competitive discounts to legitimate users.</p>
      
      <div class="explanation-grid">
        <div class="explanation-item">
          <h3>🎯 Objective</h3>
          <ul>
            <li>Protect competitive pricing</li>
            <li>Prevent price scraping</li>
            <li>Reward legitimate customers</li>
            <li>Discourage bot-driven competition</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>⚙️ Technical Implementation</h3>
          <ul>
            <li>Dynamic pricing based on bot detection</li>
            <li>Bots see inflated prices (+30%)</li>
            <li>Users see discounted prices (-25%)</li>
            <li>Real-time price adjustment</li>
          </ul>
        </div>
        
        <div class="explanation-item">
          <h3>📊 Expected Results</h3>
          <ul>
            <li>Protected pricing intelligence</li>
            <li>Reduced competitive scraping</li>
            <li>Better user experience</li>
            <li>Maintained profit margins</li>
          </ul>
        </div>
      </div>
    </div>
    
    <div class="next-steps">
      <h2>Ready to Test?</h2>
      <p>Browse flight prices to see how the system shows different pricing based on your traffic classification.</p>
      <div class="next-buttons">
        <router-link to="/bot-demo-3" class="btn btn-primary">Start Demo 3</router-link>
        <router-link to="/aws-edge-services" class="btn btn-secondary">AWS Edge Services</router-link>
        <router-link to="/bot-demo-2-info" class="btn btn-outline">Back: Demo 2 Info</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BotDemo3Info'
}
</script>
