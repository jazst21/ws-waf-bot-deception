import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import BotDemo1Info from '../views/BotDemo1Info.vue'
import BotDemo1 from '../views/BotDemo1.vue'
import BotDemo2Info from '../views/BotDemo2Info.vue'
import BotDemo2 from '../views/BotDemo2.vue'
import BotDemo3Info from '../views/BotDemo3Info.vue'
import BotDemo3 from '../views/BotDemo3.vue'
import AwsEdgeServices from '../views/AwsEdgeServices.vue'
import NotFound from '../views/NotFound.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      title: 'Bot Deception Demo'
    }
  },
  {
    path: '/bot-demo-1-info',
    name: 'BotDemo1Info',
    component: BotDemo1Info,
    meta: {
      title: 'Bot Demo 1 Info'
    }
  },
  {
    path: '/bot-demo-1',
    name: 'BotDemo1',
    component: BotDemo1,
    meta: {
      title: 'Bot Demo 1'
    }
  },
  {
    path: '/bot-demo-2-info',
    name: 'BotDemo2Info',
    component: BotDemo2Info,
    meta: {
      title: 'Bot Demo 2 Info'
    }
  },
  {
    path: '/bot-demo-2',
    name: 'BotDemo2',
    component: BotDemo2,
    meta: {
      title: 'Bot Demo 2'
    }
  },
  {
    path: '/bot-demo-3-info',
    name: 'BotDemo3Info',
    component: BotDemo3Info,
    meta: {
      title: 'Bot Demo 3 Info'
    }
  },
  {
    path: '/bot-demo-3',
    name: 'BotDemo3',
    component: BotDemo3,
    meta: {
      title: 'Bot Demo 3'
    }
  },
  {
    path: '/aws-edge-services',
    name: 'AwsEdgeServices',
    component: AwsEdgeServices,
    meta: {
      title: 'AWS Edge Services'
    }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound,
    meta: {
      title: 'Page Not Found'
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  }
})

// Global navigation guard for title updates
router.beforeEach((to, from, next) => {
  document.title = `${to.meta.title} - Bot Deception Demo`
  next()
})

export default router
