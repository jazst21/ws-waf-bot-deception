<template>
  <div id="app" class="container">
    <!-- Left Sidebar Navigation -->
    <nav class="sidebar">
      <div class="logo">
        <h2>Bot Deception</h2>
        <p>Demo</p>
      </div>
      
      <ul class="nav-menu">
        <li>
          <router-link to="/" class="nav-link">🏠 Home</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-1-info" class="nav-link">🤖 Bot Demo 1 Info</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-1" class="nav-link">⚡ Bot Demo 1</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-2-info" class="nav-link">🤖 Bot Demo 2 Info</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-2" class="nav-link">💬 Bot Demo 2</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-3-info" class="nav-link">🤖 Bot Demo 3 Info</router-link>
        </li>
        <li>
          <router-link to="/bot-demo-3" class="nav-link">✈️ Bot Demo 3</router-link>
        </li>
        <li>
          <router-link to="/aws-edge-services" class="nav-link">☁️ AWS Edge Services</router-link>
        </li>
      </ul>
      
      <div class="language-toggle">
        <button class="lang-btn" @click="toggleLanguage">
          🌐 {{ currentLanguage }}
        </button>
      </div>
    </nav>
    
    <!-- Main Content -->
    <main class="main-content">
      <div class="content-wrapper">
        <router-view />
      </div>
    </main>
    
    <!-- Loading Overlay -->
    <div v-if="isLoading" class="loading-overlay">
      <div class="loading-spinner">
        <div class="spinner"></div>
        <p>Loading...</p>
      </div>
    </div>
    
    <!-- Notification System -->
    <div class="notification-container">
      <div
        v-for="notification in notifications"
        :key="notification.id"
        :class="['notification', `notification-${notification.type}`]"
        @click="removeNotification(notification.id)"
      >
        {{ notification.message }}
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { useAppStore } from './stores/app'

export default {
  name: 'App',
  setup() {
    const appStore = useAppStore()
    const currentLanguage = ref('EN')
    const languages = ['EN', 'KO', 'JA', 'ZH']
    
    const toggleLanguage = () => {
      const currentIndex = languages.indexOf(currentLanguage.value)
      const nextIndex = (currentIndex + 1) % languages.length
      currentLanguage.value = languages[nextIndex]
      console.log(`Language switched to: ${currentLanguage.value}`)
    }
    
    const removeNotification = (id) => {
      appStore.removeNotification(id)
    }
    
    onMounted(() => {
      // Initialize app
      appStore.checkBotStatus()
    })
    
    return {
      currentLanguage,
      toggleLanguage,
      removeNotification,
      isLoading: appStore.isLoading,
      notifications: appStore.notifications
    }
  }
}
</script>

<style>
/* Loading overlay styles */
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(15, 23, 42, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

.loading-spinner {
  text-align: center;
  color: var(--text-primary);
}

.spinner {
  width: 40px;
  height: 40px;
  border: 4px solid var(--border-color);
  border-top: 4px solid var(--primary-color);
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 1rem;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Notification styles */
.notification-container {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 10001;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.notification {
  padding: 1rem 1.5rem;
  border-radius: var(--radius-md);
  color: white;
  font-weight: 600;
  max-width: 300px;
  cursor: pointer;
  transform: translateX(100%);
  animation: slideInNotification 0.3s ease forwards;
}

.notification-success {
  background-color: var(--success-color);
}

.notification-error {
  background-color: var(--danger-color);
}

.notification-warning {
  background-color: var(--warning-color);
}

.notification-info {
  background-color: var(--primary-color);
}

@keyframes slideInNotification {
  to {
    transform: translateX(0);
  }
}

/* Router link active styles */
.router-link-active {
  background-color: var(--primary-color) !important;
  color: var(--text-primary) !important;
  box-shadow: var(--shadow-md);
}
</style>
