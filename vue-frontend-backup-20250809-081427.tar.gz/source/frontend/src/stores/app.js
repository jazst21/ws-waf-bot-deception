import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api from '../services/api'

export const useAppStore = defineStore('app', () => {
  // State
  const isLoading = ref(false)
  const isBot = ref(false)
  const botMessage = ref('')
  const notifications = ref([])
  const apiStatus = ref(null)
  
  // Getters
  const getBotStatus = computed(() => ({
    isBot: isBot.value,
    message: botMessage.value
  }))
  
  const getNotifications = computed(() => notifications.value)
  
  // Actions
  const setLoading = (loading) => {
    isLoading.value = loading
  }
  
  const setBotStatus = (status, message = '') => {
    isBot.value = status
    botMessage.value = message
  }
  
  const addNotification = (message, type = 'info', duration = 3000) => {
    const id = Date.now() + Math.random()
    const notification = {
      id,
      message,
      type
    }
    
    notifications.value.push(notification)
    
    // Auto remove after duration
    setTimeout(() => {
      removeNotification(id)
    }, duration)
    
    return id
  }
  
  const removeNotification = (id) => {
    const index = notifications.value.findIndex(n => n.id === id)
    if (index > -1) {
      notifications.value.splice(index, 1)
    }
  }
  
  const clearNotifications = () => {
    notifications.value = []
  }
  
  const checkBotStatus = async () => {
    try {
      setLoading(true)
      const response = await api.getStatus()
      
      setBotStatus(response.data.isBot, response.data.message)
      apiStatus.value = response.data
      
      if (response.data.isBot) {
        addNotification('Bot traffic detected!', 'warning', 5000)
      }
    } catch (error) {
      console.error('Failed to check bot status:', error)
      addNotification('Failed to connect to API', 'error')
    } finally {
      setLoading(false)
    }
  }
  
  const handleApiError = (error) => {
    console.error('API Error:', error)
    
    let message = 'An error occurred'
    if (error.response) {
      message = error.response.data?.message || `Server error: ${error.response.status}`
    } else if (error.request) {
      message = 'Network error - please check your connection'
    } else {
      message = error.message
    }
    
    addNotification(message, 'error')
  }
  
  return {
    // State
    isLoading,
    isBot,
    botMessage,
    notifications,
    apiStatus,
    
    // Getters
    getBotStatus,
    getNotifications,
    
    // Actions
    setLoading,
    setBotStatus,
    addNotification,
    removeNotification,
    clearNotifications,
    checkBotStatus,
    handleApiError
  }
})
