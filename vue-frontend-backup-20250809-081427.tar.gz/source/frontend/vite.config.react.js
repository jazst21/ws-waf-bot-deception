import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

export default defineConfig({
  plugins: [react()],
  root: '.', 
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src-react')
    }
  },
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
        secure: false
      }
    }
  },
  build: {
    outDir: 'dist-react',
    assetsDir: 'assets',
    sourcemap: false,
    rollupOptions: {
      input: resolve(__dirname, 'index-react.html'),
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router-dom', 'axios']
        }
      }
    }
  },
  // Explicitly exclude Vue files and directories
  optimizeDeps: {
    exclude: ['src/**/*.vue', 'src/views/**', 'src/components/**', 'src/stores/**']
  },
  // Only scan React source directory
  esbuild: {
    include: /src-react\/.*\.(jsx?|tsx?)$/,
    exclude: /src\/.*\.vue$/
  },
  define: {
    'process.env': process.env
  }
})
