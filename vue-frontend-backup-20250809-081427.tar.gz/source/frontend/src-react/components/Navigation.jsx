import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { SideNavigation, Button, Box, SpaceBetween } from '@cloudscape-design/components'

function Navigation({ currentLanguage, onLanguageToggle }) {
  const location = useLocation()
  const navigate = useNavigate()

  // PRESERVE EXACT navigation items from Vue version
  const navigationItems = [
    {
      type: 'link',
      text: '🏠 Home',
      href: '/'
    },
    {
      type: 'link',
      text: '🤖 Bot Demo 1 Info',
      href: '/bot-demo-1-info'
    },
    {
      type: 'link',
      text: '⚡ Bot Demo 1',
      href: '/bot-demo-1'
    },
    {
      type: 'link',
      text: '🤖 Bot Demo 2 Info',
      href: '/bot-demo-2-info'
    },
    {
      type: 'link',
      text: '💬 Bot Demo 2',
      href: '/bot-demo-2'
    },
    {
      type: 'link',
      text: '🤖 Bot Demo 3 Info',
      href: '/bot-demo-3-info'
    },
    {
      type: 'link',
      text: '✈️ Bot Demo 3',
      href: '/bot-demo-3'
    },
    {
      type: 'link',
      text: '☁️ AWS Edge Services',
      href: '/aws-edge-services'
    }
  ]

  const handleFollow = (event) => {
    event.preventDefault()
    const href = event.detail.href
    navigate(href)
  }

  return (
    <SpaceBetween direction="vertical" size="l">
      {/* Logo section - PRESERVE same branding as Vue */}
      <Box padding="l">
        <div className="logo">
          <h2>Bot Deception</h2>
          <p>Demo</p>
        </div>
      </Box>

      {/* Navigation menu - PRESERVE same structure as Vue */}
      <SideNavigation
        activeHref={location.pathname}
        items={navigationItems}
        onFollow={handleFollow}
      />

      {/* Language toggle - PRESERVE same functionality as Vue */}
      <Box padding="l">
        <Button
          variant="normal"
          iconName="globe"
          onClick={onLanguageToggle}
          fullWidth
        >
          🌐 {currentLanguage}
        </Button>
      </Box>
    </SpaceBetween>
  )
}

export default Navigation
