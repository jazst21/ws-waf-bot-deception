import { applyMode, Mode } from '@cloudscape-design/global-styles'

// Apply dark mode to match the existing dark theme
applyMode(Mode.Dark)

// Custom theme configuration to match existing design
export const customTheme = {
  // Color mapping from existing CSS variables to Cloudscape
  colors: {
    // Primary colors - map to existing --primary-color
    primary: '#2563eb',
    primaryDark: '#1d4ed8',
    
    // Secondary colors
    secondary: '#7c3aed',
    accent: '#06b6d4',
    
    // Status colors - preserve existing
    success: '#10b981',
    warning: '#f59e0b',
    error: '#ef4444',
    
    // Background colors - preserve dark theme
    backgroundPrimary: '#0f172a',
    backgroundSecondary: '#1e293b',
    backgroundTertiary: '#334155',
    
    // Text colors - preserve existing
    textPrimary: '#f8fafc',
    textSecondary: '#cbd5e1',
    textMuted: '#64748b',
    
    // Border colors
    border: '#475569'
  },
  
  // Spacing system - map existing CSS variables
  spacing: {
    xs: '0.25rem',
    sm: '0.5rem',
    md: '1rem',
    lg: '1.5rem',
    xl: '2rem',
    xxl: '3rem'
  },
  
  // Typography - preserve existing font family
  typography: {
    fontFamily: "'Noto Sans KR', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      xxl: '1.5rem',
      xxxl: '1.875rem'
    }
  },
  
  // Border radius - preserve existing
  borderRadius: {
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem'
  },
  
  // Shadows - preserve existing
  shadows: {
    sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
    md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
    lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
    xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)'
  },
  
  // Layout dimensions - preserve existing
  layout: {
    sidebarWidth: '280px',
    sidebarWidthTablet: '240px',
    headerHeight: '80px',
    contentMaxWidth: '1200px'
  }
}

export default customTheme
