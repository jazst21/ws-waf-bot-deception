import React, { useEffect, useState } from 'react'
import { Container, Header, SpaceBetween, Button, Box, Alert } from '@cloudscape-design/components'
import { useApi } from '../hooks/useApi'
import LoadingSpinner from '../components/LoadingSpinner'

function BotDemo1() {
  const [demoData, setDemoData] = useState(null)
  const [isRunning, setIsRunning] = useState(false)
  const { getBotDemo1, loading } = useApi()

  const handleRunDemo = async () => {
    try {
      setIsRunning(true)
      const response = await getBotDemo1()
      setDemoData(response.data)
    } catch (error) {
      console.error('Demo failed:', error)
    } finally {
      setIsRunning(false)
    }
  }

  return (
    <Container>
      <SpaceBetween direction="vertical" size="l">
        <Header variant="h1">⚡ Bot Demo 1 - Timeout Induction</Header>
        
        <Alert type="info">
          This demo shows how bots can be induced to timeout when accessing certain endpoints.
        </Alert>

        <Box>
          <Button 
            variant="primary" 
            onClick={handleRunDemo}
            loading={isRunning || loading}
          >
            Run Timeout Demo
          </Button>
        </Box>

        {demoData && (
          <Box variant="code">
            <pre>{JSON.stringify(demoData, null, 2)}</pre>
          </Box>
        )}
      </SpaceBetween>
    </Container>
  )
}

export default BotDemo1
