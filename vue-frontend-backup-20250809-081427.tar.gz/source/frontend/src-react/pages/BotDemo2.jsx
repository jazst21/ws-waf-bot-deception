import React, { useEffect, useState } from 'react'
import { Container, Header, SpaceBetween, Button, Box, Alert, Form, FormField, Input, Textarea } from '@cloudscape-design/components'
import { useApi } from '../hooks/useApi'
import { useNotifications } from '../hooks/useNotifications'
import LoadingSpinner from '../components/LoadingSpinner'

function BotDemo2() {
  const [comments, setComments] = useState([])
  const [newComment, setNewComment] = useState({ name: '', comment: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { getBotDemo2Comments, postBotDemo2Comment, loading } = useApi()
  const { showSuccess, showError } = useNotifications()

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await getBotDemo2Comments()
        setComments(response.data.comments || [])
      } catch (error) {
        console.error('Failed to fetch comments:', error)
      }
    }

    fetchComments()
  }, [getBotDemo2Comments])

  const handleSubmitComment = async (e) => {
    e.preventDefault()
    if (!newComment.name || !newComment.comment) return

    try {
      setIsSubmitting(true)
      await postBotDemo2Comment(newComment)
      showSuccess('Comment submitted successfully!')
      setNewComment({ name: '', comment: '' })
      
      // Refresh comments
      const response = await getBotDemo2Comments()
      setComments(response.data.comments || [])
    } catch (error) {
      showError('Failed to submit comment')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Container>
      <SpaceBetween direction="vertical" size="l">
        <Header variant="h1">💬 Bot Demo 2 - Silent Discard</Header>
        
        <Alert type="info">
          This demo shows how bot comments can be silently discarded while appearing successful to the bot.
        </Alert>

        {/* Comment Form */}
        <Container>
          <form onSubmit={handleSubmitComment}>
            <SpaceBetween direction="vertical" size="m">
              <FormField label="Name">
                <Input
                  value={newComment.name}
                  onChange={({ detail }) => setNewComment(prev => ({ ...prev, name: detail.value }))}
                  placeholder="Enter your name"
                />
              </FormField>
              
              <FormField label="Comment">
                <Textarea
                  value={newComment.comment}
                  onChange={({ detail }) => setNewComment(prev => ({ ...prev, comment: detail.value }))}
                  placeholder="Enter your comment"
                  rows={4}
                />
              </FormField>
              
              <Button 
                variant="primary" 
                type="submit"
                loading={isSubmitting}
                disabled={!newComment.name || !newComment.comment}
              >
                Submit Comment
              </Button>
            </SpaceBetween>
          </form>
        </Container>

        {/* Comments Display */}
        <Container>
          <Header variant="h3">Comments ({comments.length})</Header>
          {loading ? (
            <LoadingSpinner text="Loading comments..." />
          ) : (
            <SpaceBetween direction="vertical" size="s">
              {comments.map((comment, index) => (
                <Box key={index} padding="s" variant="div">
                  <strong>{comment.name}</strong>: {comment.comment}
                </Box>
              ))}
              {comments.length === 0 && (
                <Box>No comments yet. Be the first to comment!</Box>
              )}
            </SpaceBetween>
          )}
        </Container>
      </SpaceBetween>
    </Container>
  )
}

export default BotDemo2
