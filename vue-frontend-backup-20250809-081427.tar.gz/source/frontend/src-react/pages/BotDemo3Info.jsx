import React, { useEffect, useState } from 'react'
import { Container, Header, SpaceBetween, Box } from '@cloudscape-design/components'
import { useApi } from '../hooks/useApi'
import LoadingSpinner from '../components/LoadingSpinner'

function BotDemo3Info() {
  const [infoData, setInfoData] = useState(null)
  const { getBotDemo3Info, loading } = useApi()

  useEffect(() => {
    const fetchInfo = async () => {
      try {
        const response = await getBotDemo3Info()
        setInfoData(response.data)
      } catch (error) {
        console.error('Failed to fetch Bot Demo 3 info:', error)
      }
    }

    fetchInfo()
  }, [getBotDemo3Info])

  if (loading) {
    return <LoadingSpinner text="Loading Bot Demo 3 information..." />
  }

  return (
    <Container>
      <SpaceBetween direction="vertical" size="l">
        <Header variant="h1">🤖 Bot Demo 3 Info</Header>
        <Box>
          <p>Information about the price manipulation demo will be displayed here.</p>
          {infoData && (
            <Box variant="code">
              <pre>{JSON.stringify(infoData, null, 2)}</pre>
            </Box>
          )}
        </Box>
      </SpaceBetween>
    </Container>
  )
}

export default BotDemo3Info
