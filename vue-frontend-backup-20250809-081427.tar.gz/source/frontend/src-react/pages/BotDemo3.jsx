import React, { useEffect, useState } from 'react'
import { Container, Header, SpaceBetween, Button, Box, Alert, Table } from '@cloudscape-design/components'
import { useApi } from '../hooks/useApi'
import LoadingSpinner from '../components/LoadingSpinner'

function BotDemo3() {
  const [flights, setFlights] = useState([])
  const { getBotDemo3Flights, loading } = useApi()

  useEffect(() => {
    const fetchFlights = async () => {
      try {
        const response = await getBotDemo3Flights()
        setFlights(response.data.flights || [])
      } catch (error) {
        console.error('Failed to fetch flights:', error)
      }
    }

    fetchFlights()
  }, [getBotDemo3Flights])

  const handleRefresh = async () => {
    try {
      const response = await getBotDemo3Flights()
      setFlights(response.data.flights || [])
    } catch (error) {
      console.error('Failed to refresh flights:', error)
    }
  }

  const columnDefinitions = [
    {
      id: 'airline',
      header: 'Airline',
      cell: item => item.airline
    },
    {
      id: 'departure',
      header: 'Departure',
      cell: item => item.departure
    },
    {
      id: 'arrival',
      header: 'Arrival',
      cell: item => item.arrival
    },
    {
      id: 'price',
      header: 'Price',
      cell: item => `$${item.price}`
    }
  ]

  return (
    <Container>
      <SpaceBetween direction="vertical" size="l">
        <Header variant="h1">✈️ Bot Demo 3 - Price Manipulation</Header>
        
        <Alert type="info">
          This demo shows how flight prices can be manipulated for bot traffic.
        </Alert>

        <Box>
          <Button 
            variant="primary" 
            onClick={handleRefresh}
            loading={loading}
          >
            Refresh Flights
          </Button>
        </Box>

        {loading ? (
          <LoadingSpinner text="Loading flight data..." />
        ) : (
          <Table
            columnDefinitions={columnDefinitions}
            items={flights}
            empty={
              <Box textAlign="center" color="inherit">
                <b>No flights available</b>
                <Box padding={{ bottom: 's' }} variant="p" color="inherit">
                  No flights to display.
                </Box>
              </Box>
            }
          />
        )}
      </SpaceBetween>
    </Container>
  )
}

export default BotDemo3
